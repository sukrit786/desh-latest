import { FilterdatePipe } from './filterdate.pipe';

describe('FilterdatePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterdatePipe();
    expect(pipe).toBeTruthy();
  });
});
