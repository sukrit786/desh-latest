import { FilterNamePipe } from './filter-name.pipe';

describe('FilterNamePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterNamePipe();
    expect(pipe).toBeTruthy();
  });
});
